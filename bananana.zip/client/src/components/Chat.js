import React, { Component } from "react";

class Chat extends Component {
  render() {
    return (
      <div className="container">
        <div>Chat</div>
      </div>
    );
  }
}

export default Chat;
